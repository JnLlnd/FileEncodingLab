# FileEncodingLab
Explore file enconding with AutoHotkey and cheat sheet about file encoding (ASCII, ANSI, UTF-8, UTF-16, etc)
